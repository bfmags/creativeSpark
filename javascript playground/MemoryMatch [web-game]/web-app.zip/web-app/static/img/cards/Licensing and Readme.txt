This is an icon set you may use in personal projects.
You may use the included template to create your own icons. 

You are not allowed to repackage or include this into an icon pack or similar.
If you want to share my work, please use either of the following links:

On my portfolio:
http://uix.me/projects/hexagon-android-icon-set/

On Dribbbble
http://dribbble.com/shots/1236957-Hexagon-Android-Icon-Theme?list=following

On My Color Screen
http://mycolorscreen.com/2013/09/15/hexagons-3/

Missing a specific icon ? 
Either try creating your own using the included PSD or contact me @iamkadir on twitter. 

---
Commercial use:
Please get in contact with me (see below).
---
I am a designer and available for work.

Feel free to contact me via:
E-Mail: 
hello@uix.me
or 
Twitter:
@iamkadir
